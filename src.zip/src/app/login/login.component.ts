import { Component, OnInit } from '@angular/core';
import {Router} from '@angular/router';


@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent  implements OnInit{
  usuario: String = '';
  password: String = '';
  
  validacion= {
    usuario : "Thomas",
    password : "123"
  }
  

 constructor(private router:Router){
 }
 ngOnInit(): void{

 }

 iniciarSesion(){


  if (this.usuario != '' && this.password != ''){
      if(this.usuario === this.validacion.usuario){ 
        if (this.password === this.validacion.password) {
          alert("Bienvenido al dashboard " + this.usuario )
          this.router.navigate(['dashboard']);
          return
        }else{
          alert("Contraseña incorrecta")
          return
        }
      }else{
        alert("Las credenciales no son validas")
      }
      
      
  }else{
    alert("Los campos no pueden estar vacíos")
  }
  
  
 }

}
